package in.co.daily.expense.Exception;

public class RecordNotFoundException extends Exception{

	public RecordNotFoundException(String msg) {

		super(msg);
	}
}
