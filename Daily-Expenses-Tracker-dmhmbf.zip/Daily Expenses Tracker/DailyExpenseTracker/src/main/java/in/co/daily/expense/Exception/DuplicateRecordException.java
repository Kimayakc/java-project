package in.co.daily.expense.Exception;

public class DuplicateRecordException extends Exception{

	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
