package in.co.daily.expense.Bean;

public interface DropDownListBean {

	
	public String getkey();
	
	public String getvalue();
	
}
