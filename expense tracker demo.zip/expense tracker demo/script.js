const balance = document.getElementById('balance');
const money_plus = document.getElementById('money-plus');
const money_minus = document.getElementById('money-minus');
const list = document.getElementById('list');
const form = document.getElementById('form');
const text = document.getElementById('text');
const amount = document.getElementById('amount');

// const dummyTransactions = [
//   { id: 1, text: 'Flower', amount: -20 },
//   { id: 2, text: 'Salary', amount: 300 },
//   { id: 3, text: 'Book', amount: -10 },
//   { id: 4, text: 'Camera', amount: 150 }
// ];

const localStorageTransactions = JSON.parse(
    localStorage.getItem('transactions')
);

let transactions =
    localStorage.getItem('transactions') !== null ? localStorageTransactions : [];

// Add transaction
function addTransaction(e) {
    e.preventDefault();

    if (text.value.trim() === '' || amount.value.trim() === '') {
        alert('Please add a text and amount');
    } else {
        const transaction = {
            id: generateID(),
            text: text.value,
            amount: +amount.value
        };

        transactions.push(transaction);

        addTransactionDOM(transaction);

        updateValues();

        updateLocalStorage();

        text.value = '';
        amount.value = '';
    }
}

// Generate random ID
function generateID() {
    return Math.floor(Math.random() * 100000000);
}

// Add transactions to DOM list
function addTransactionDOM(transaction) {
    // Get sign
    const sign = transaction.amount < 0 ? '-' : '+';

    const item = document.createElement('li');

    // Add class based on value
    item.classList.add(transaction.amount < 0 ? 'minus' : 'plus');

    item.innerHTML = `
    ${transaction.text} <span>${sign}${Math.abs(
    transaction.amount
  )}</span> <button class="delete-btn" onclick="removeTransaction(${
    transaction.id
  })">x</button>
  `;

    list.appendChild(item);
}

// Update the balance, income and expense
function updateValues() {
    const amounts = transactions.map(transaction => transaction.amount);

    const total = amounts.reduce((acc, item) => (acc += item), 0).toFixed(2);

    const income = amounts
        .filter(item => item > 0)
        .reduce((acc, item) => (acc += item), 0)
        .toFixed(2);

    const expense = (
        amounts.filter(item => item < 0).reduce((acc, item) => (acc += item), 0) *
        -1
    ).toFixed(2);

    balance.innerText = `$${total}`;
    money_plus.innerText = `$${income}`;
    money_minus.innerText = `$${expense}`;
}

// Remove transaction by ID
function removeTransaction(id) {
    transactions = transactions.filter(transaction => transaction.id !== id);

    updateLocalStorage();

    init();
}

// Update local storage transactions
function updateLocalStorage() {
    localStorage.setItem('transactions', JSON.stringify(transactions));
}

// Init app
function init() {
    list.innerHTML = '';

    transactions.forEach(addTransactionDOM);
    updateValues();
}

init();

form.addEventListener('submit', addTransaction);










// Get the list element and the filter elements
// const list = document.getElementById("list");
const filterWeek = document.getElementById("filter-week");
const filterYear = document.getElementById("filter-year");
const filterMonth = document.getElementById("filter-month");

// Add event listeners to the filter elements
filterWeek.addEventListener("click", filterByWeek);
filterYear.addEventListener("click", filterByYear);
filterMonth.addEventListener("change", filterByMonth);

// Define the filter functions
function filterByWeek() {
    // Get the current date and the first and last day of the current week
    const today = moment();
    const firstDay = today.startOf("week");
    const lastDay = today.endOf("week");

    // Filter the list items by the date attribute
    const filteredItems = Array.from(list.children).filter((item) => {
        const itemDate = moment(item.dataset.date);
        return itemDate.isBetween(firstDay, lastDay, "day", "[]");
    });

    // Update the list with the filtered items
    updateList(filteredItems);
}

function filterByYear() {
    // Get the current date and the year
    const today = moment();
    const year = today.year();

    // Filter the list items by the date attribute
    const filteredItems = Array.from(list.children).filter((item) => {
        const itemDate = moment(item.dataset.date);
        return itemDate.year() === year;
    });

    // Update the list with the filtered items
    updateList(filteredItems);
}

function filterByMonth() {
    // Get the selected month and year from the input element
    const monthYear = filterMonth.value;
    const [year, month] = monthYear.split("-");

    // Filter the list items by the date attribute
    const filteredItems = Array.from(list.children).filter((item) => {
        const itemDate = moment(item.dataset.date);
        return itemDate.year() === parseInt(year) && itemDate.month() === parseInt(month) - 1;
    });

    // Update the list with the filtered items
    updateList(filteredItems);
}

// Define a helper function to update the list with the filtered items
function updateList(items) {
    // Clear the list
    list.innerHTML = "";

    // Append the filtered items to the list
    items.forEach((item) => {
        list.appendChild(item);
    });

    // Update the balance, income and expense
    updateValues();
}